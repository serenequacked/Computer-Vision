  
function ret = dmap(Il, Ir, x_temp, y_temp)
% Fuction to calculate disparity map

% calculate half size of template
size_x = floor(x_temp/2);
size_y = floor(y_temp/2);

% Il and Ir must have the same size
[x, y] = size(Il);

%initialization
ret = ones(x - x_temp + 1, y - y_temp + 1);

if size(Il) ~= size(Ir)
    error("Ensure both images are the same size!")
else
    for i = 1+size_x : x-size_x
        for j = 1+size_y : y-size_y
            cur_r = Il(i-size_x: i+size_x, j-size_y: j+size_y);
            cur_l = rot90(cur_r, 2);
            min_coor = j; 
            min_diff = inf;

            % search for simmilar pattern in right image
            % limit search to 15 pixel to the left
            for k = max(1+size_y , j-14) : j
                T = Ir(i-size_x: i+size_x, k-size_y: k+size_y);
                cur_r = rot90(T, 2);

                % Calculate ssd and update minimum diff
                conv_1 = conv2(T, cur_r);
                conv_2 = conv2(T, cur_l);
                ssd = conv_1(x_temp, y_temp) - 2 * conv_2(x_temp, y_temp);
                if ssd < min_diff
                    min_diff = ssd;
                    min_coor = k;
                end
            end
            ret(i - size_x, j - size_y) = j - min_coor;
        end
    end
end